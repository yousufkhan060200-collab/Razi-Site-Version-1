"use client";

import Link from "next/link";
import { useState } from "react";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import type { Clinic } from "@/types/clinic";

export function IntakeLinkCard({ clinic }: { clinic: Clinic }) {
  const [copied, setCopied] = useState(false);

  return (
    <Card>
      <CardHeader className="space-y-2">
        <p className="text-sm font-semibold uppercase tracking-[0.18em] text-brand-600">
          Unique clinic link
        </p>
        <h3 className="text-xl font-semibold text-ink-900">
          Intake URL + QR access
        </h3>
      </CardHeader>
      <CardContent className="grid gap-6 lg:grid-cols-[1fr_220px]">
        <div className="space-y-4">
          <div className="rounded-3xl bg-brand-50 p-4">
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-ink-500">
              Clinic URL
            </p>
            <p className="mt-2 break-all text-sm text-ink-800">
              {clinic.intakeLink.uniqueUrl}
            </p>
          </div>
          <div className="flex flex-wrap gap-3">
            <Button
              onClick={async () => {
                await navigator.clipboard.writeText(clinic.intakeLink.uniqueUrl);
                setCopied(true);
                window.setTimeout(() => setCopied(false), 1600);
              }}
              variant="primary"
            >
              {copied ? "Copied" : "Copy link"}
            </Button>
            <a download={`${clinic.slug}-qr.png`} href={clinic.qrCodeUrl}>
              <Button variant="secondary">Download QR</Button>
            </a>
            <Link href={`/intake/${clinic.slug}`}>
              <Button variant="ghost">Preview clinic page</Button>
            </Link>
          </div>
          <p className="text-xs text-ink-500">
            This QR and URL are mocked for the starter. Connect to your real clinic provisioning flow later.
          </p>
        </div>
        <div className="mx-auto rounded-[2rem] border border-brand-100 bg-white p-4 shadow-card">
          <img
            alt={`${clinic.name} intake QR`}
            className="h-[188px] w-[188px] rounded-2xl"
            src={clinic.qrCodeUrl}
          />
        </div>
      </CardContent>
    </Card>
  );
}
