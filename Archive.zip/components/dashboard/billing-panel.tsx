import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { formatDate } from "@/lib/utils/format";
import type { Clinic } from "@/types/clinic";

export function BillingPanel({ clinic }: { clinic: Clinic }) {
  const trial = clinic.subscription.trial;

  return (
    <Card>
      <CardHeader className="space-y-2">
        <p className="text-sm font-semibold uppercase tracking-[0.18em] text-brand-600">
          Subscription management
        </p>
        <h3 className="text-xl font-semibold text-ink-900">
          Trial and billing framework
        </h3>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex flex-wrap items-center gap-3">
          <Badge tone={clinic.subscriptionStatus === "active" ? "success" : clinic.subscriptionStatus === "trial" ? "brand" : "warning"}>
            {clinic.subscription.subscriptionStatus}
          </Badge>
          <span className="text-sm text-ink-500">{trial.statusLabel}</span>
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          <InfoLine label="Current plan" value={clinic.subscription.planName} />
          <InfoLine label="Billing cycle" value={clinic.subscription.billingCycle} />
          <InfoLine label="Trial start" value={formatDate(trial.startDate)} />
          <InfoLine label="Trial end" value={formatDate(trial.endDate)} />
          <InfoLine label="Stripe customer ID" value={clinic.billing.stripeCustomerId} />
          <InfoLine
            label="Stripe subscription ID"
            value={clinic.billing.stripeSubscriptionId}
          />
          <InfoLine
            label="Payment method"
            value={`${clinic.billing.cardBrand} ending in ${clinic.billing.last4}`}
          />
          <InfoLine
            label="Expiration"
            value={`${clinic.billing.expMonth}/${clinic.billing.expYear}`}
          />
        </div>

        <div className="rounded-3xl bg-brand-50 p-4 text-sm text-ink-700">
          <p className="font-medium text-ink-900">Trial messaging</p>
          <p className="mt-2">{trial.message}</p>
        </div>

        <div className="flex flex-wrap gap-3">
          <Button variant="secondary">Manage billing</Button>
          <Button variant="secondary">Update payment method</Button>
          <Button variant="danger">Cancel subscription</Button>
        </div>
      </CardContent>
    </Card>
  );
}

function InfoLine({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-brand-100 bg-white px-4 py-3">
      <p className="text-xs font-semibold uppercase tracking-[0.18em] text-ink-500">
        {label}
      </p>
      <p className="mt-2 text-sm text-ink-800">{value}</p>
    </div>
  );
}
