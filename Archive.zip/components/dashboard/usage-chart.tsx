import { cn } from "@/lib/utils/cn";
import type { UsagePoint } from "@/types/stats";

export function UsageChart({
  title,
  points
}: {
  title: string;
  points: UsagePoint[];
}) {
  const maxValue = Math.max(...points.map((point) => point.value), 1);

  return (
    <div className="rounded-3xl border border-brand-100 bg-white p-6 shadow-card">
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-ink-900">{title}</h3>
        <p className="mt-1 text-sm text-ink-500">
          Estimated usage trend placeholder. Swap this with a richer chart library later if needed.
        </p>
      </div>
      <div className="flex h-56 items-end gap-3">
        {points.map((point) => {
          const height = Math.max((point.value / maxValue) * 100, 8);

          return (
            <div key={point.label} className="flex flex-1 flex-col items-center gap-3">
              <div className="text-xs font-medium text-ink-500">{point.value}</div>
              <div className="flex h-full w-full items-end">
                <div
                  className={cn(
                    "w-full rounded-t-2xl bg-gradient-to-b from-brand-300 to-brand-600"
                  )}
                  style={{ height: `${height}%` }}
                />
              </div>
              <div className="text-xs text-ink-500">{point.label}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
