import * as React from "react";

import { cn } from "@/lib/utils/cn";

interface FieldProps {
  label?: string;
  hint?: string;
  className?: string;
}

export function Input({
  label,
  hint,
  className,
  ...props
}: React.InputHTMLAttributes<HTMLInputElement> & FieldProps) {
  return (
    <label className="block space-y-2">
      {label ? (
        <span className="text-sm font-medium text-ink-700">{label}</span>
      ) : null}
      <input
        className={cn(
          "h-11 w-full rounded-2xl border border-brand-100 bg-white px-4 text-sm text-ink-900 placeholder:text-ink-400 focus:border-brand-300 focus:outline-none focus:ring-4 focus:ring-brand-100",
          className
        )}
        {...props}
      />
      {hint ? <span className="text-xs text-ink-500">{hint}</span> : null}
    </label>
  );
}

export function Textarea({
  label,
  hint,
  className,
  ...props
}: React.TextareaHTMLAttributes<HTMLTextAreaElement> & FieldProps) {
  return (
    <label className="block space-y-2">
      {label ? (
        <span className="text-sm font-medium text-ink-700">{label}</span>
      ) : null}
      <textarea
        className={cn(
          "min-h-[120px] w-full rounded-3xl border border-brand-100 bg-white px-4 py-3 text-sm text-ink-900 placeholder:text-ink-400 focus:border-brand-300 focus:outline-none focus:ring-4 focus:ring-brand-100",
          className
        )}
        {...props}
      />
      {hint ? <span className="text-xs text-ink-500">{hint}</span> : null}
    </label>
  );
}

export function Select({
  label,
  hint,
  className,
  children,
  ...props
}: React.SelectHTMLAttributes<HTMLSelectElement> & FieldProps) {
  return (
    <label className="block space-y-2">
      {label ? (
        <span className="text-sm font-medium text-ink-700">{label}</span>
      ) : null}
      <select
        className={cn(
          "h-11 w-full rounded-2xl border border-brand-100 bg-white px-4 text-sm text-ink-900 focus:border-brand-300 focus:outline-none focus:ring-4 focus:ring-brand-100",
          className
        )}
        {...props}
      >
        {children}
      </select>
      {hint ? <span className="text-xs text-ink-500">{hint}</span> : null}
    </label>
  );
}
