import { Card, CardContent } from "@/components/ui/card";

interface StatCardProps {
  label: string;
  value: string;
  detail?: string;
}

export function StatCard({ label, value, detail }: StatCardProps) {
  return (
    <Card>
      <CardContent className="space-y-2">
        <p className="text-sm font-medium text-ink-500">{label}</p>
        <p className="text-3xl font-semibold tracking-tight text-ink-900">
          {value}
        </p>
        {detail ? <p className="text-sm text-ink-500">{detail}</p> : null}
      </CardContent>
    </Card>
  );
}
