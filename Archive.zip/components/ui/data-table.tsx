import { cn } from "@/lib/utils/cn";

interface Column<T> {
  key: keyof T | string;
  header: string;
  className?: string;
  render?: (row: T) => React.ReactNode;
}

interface DataTableProps<T> {
  columns: Array<Column<T>>;
  rows: T[];
  getRowKey: (row: T) => string;
}

export function DataTable<T>({
  columns,
  rows,
  getRowKey
}: DataTableProps<T>) {
  return (
    <div className="overflow-hidden rounded-3xl border border-brand-100 bg-white shadow-card">
      <div className="overflow-x-auto">
        <table className="min-w-full text-left text-sm">
          <thead className="bg-brand-50 text-ink-600">
            <tr>
              {columns.map((column) => (
                <th
                  key={String(column.key)}
                  className={cn("px-5 py-4 font-medium", column.className)}
                >
                  {column.header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr key={getRowKey(row)} className="border-t border-brand-50">
                {columns.map((column) => (
                  <td
                    key={String(column.key)}
                    className={cn("px-5 py-4 align-top text-ink-700", column.className)}
                  >
                    {column.render
                      ? column.render(row)
                      : String((row as Record<string, unknown>)[String(column.key)] ?? "")}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
