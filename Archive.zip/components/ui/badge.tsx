import { cn } from "@/lib/utils/cn";

interface BadgeProps {
  children: React.ReactNode;
  tone?: "brand" | "neutral" | "success" | "warning" | "danger";
  className?: string;
}

const toneStyles = {
  brand: "bg-brand-100 text-brand-700",
  neutral: "bg-ink-100 text-ink-700",
  success: "bg-emerald-100 text-emerald-700",
  warning: "bg-amber-100 text-amber-700",
  danger: "bg-rose-100 text-rose-700"
};

export function Badge({
  children,
  tone = "neutral",
  className
}: BadgeProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-3 py-1 text-xs font-semibold",
        toneStyles[tone],
        className
      )}
    >
      {children}
    </span>
  );
}
