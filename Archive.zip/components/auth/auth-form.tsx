"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useState } from "react";

import { createMockUser, useAuth } from "@/components/auth/auth-provider";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Input, Textarea } from "@/components/ui/form-fields";
import { SAMPLE_ACCOUNTS } from "@/lib/auth/constants";

type AuthMode = "login" | "signup" | "forgot";

export function AuthForm({ mode }: { mode: AuthMode }) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const redirectTo = searchParams.get("redirect") ?? "/dashboard";
  const { signIn } = useAuth();
  const [submitted, setSubmitted] = useState(false);

  const isForgot = mode === "forgot";
  const isSignup = mode === "signup";

  return (
    <Card className="w-full max-w-2xl">
      <CardHeader className="space-y-3">
        <p className="text-sm font-semibold uppercase tracking-[0.18em] text-brand-600">
          {mode === "login"
            ? "Mock login"
            : mode === "signup"
              ? "Mock account setup"
              : "Password recovery"}
        </p>
        <h1 className="text-3xl font-semibold text-ink-900">
          {mode === "login"
            ? "Access the Razi starter"
            : mode === "signup"
              ? "Create your clinic workspace"
              : "Reset your password"}
        </h1>
        <p className="text-sm leading-7 text-ink-600">
          {mode === "forgot"
            ? "This starter uses frontend-only password recovery messaging. Connect email delivery later."
            : "Authentication is mocked for now so Claude can later swap in a real auth provider without rebuilding the whole app structure."}
        </p>
      </CardHeader>
      <CardContent className="space-y-6">
        {mode !== "forgot" ? (
          <div className="rounded-3xl bg-brand-50 p-4 text-sm text-ink-700">
            <p className="font-medium text-ink-900">Demo credentials</p>
            <p className="mt-1">
              Clinic user: {SAMPLE_ACCOUNTS.clinicUser.email} / {SAMPLE_ACCOUNTS.clinicUser.password}
            </p>
            <p>
              Admin: {SAMPLE_ACCOUNTS.admin.email} / {SAMPLE_ACCOUNTS.admin.password}
            </p>
          </div>
        ) : null}

        <form
          className="grid gap-4"
          onSubmit={(event) => {
            event.preventDefault();

            const formData = new FormData(event.currentTarget);
            const email = String(formData.get("email") ?? "");
            const name = String(
              formData.get("name") ??
                (email.includes("admin") ? "Razi Admin" : "Clinic Operations")
            );

            if (isForgot) {
              setSubmitted(true);
              return;
            }

            const user = createMockUser({
              name,
              email,
              clinicId: "clinic-desert-urgent"
            });

            signIn(user);
            router.push(user.role === "admin" ? "/admin" : redirectTo);
            router.refresh();
          }}
        >
          {isSignup ? (
            <>
              <div className="grid gap-4 md:grid-cols-2">
                <Input label="Your name" name="name" placeholder="Taylor Morgan" required />
                <Input
                  label="Urgent care / clinic name"
                  name="clinicName"
                  placeholder="Desert Urgent Care"
                  required
                />
              </div>
              <Textarea
                label="Urgent care address"
                name="address"
                placeholder="2401 N Central Ave, Phoenix, AZ 85004"
                required
              />
              <Input
                label="Urgent care phone number"
                name="phone"
                placeholder="(602) 555-0184"
                required
              />
            </>
          ) : null}

          <Input
            label="Email"
            name="email"
            placeholder={mode === "login" ? SAMPLE_ACCOUNTS.clinicUser.email : "you@clinic.com"}
            required
            type="email"
          />

          {mode !== "forgot" ? (
            <Input
              label="Password"
              name="password"
              placeholder="demo1234"
              required
              type="password"
            />
          ) : null}

          <div className="flex flex-wrap items-center gap-3">
            <Button type="submit">
              {mode === "login"
                ? "Log in"
                : mode === "signup"
                  ? "Create account"
                  : "Send reset link"}
            </Button>
            {mode === "login" ? (
              <Link className="text-sm text-brand-600 hover:text-brand-700" href="/forgot-password">
                Forgot password?
              </Link>
            ) : null}
          </div>
        </form>

        {submitted ? (
          <p className="rounded-2xl bg-emerald-50 px-4 py-3 text-sm text-emerald-700">
            Password reset request captured locally. Connect your real email provider and auth backend here next.
          </p>
        ) : null}

        <div className="flex flex-wrap gap-4 text-sm text-ink-500">
          {mode !== "login" ? (
            <Link className="hover:text-ink-900" href="/login">
              Back to login
            </Link>
          ) : null}
          {mode !== "signup" ? (
            <Link className="hover:text-ink-900" href="/signup">
              Need a clinic account?
            </Link>
          ) : null}
        </div>
      </CardContent>
    </Card>
  );
}
