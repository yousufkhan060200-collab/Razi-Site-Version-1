"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState
} from "react";

import { createMockUser, destroyMockSession, persistMockSession } from "@/lib/auth/client";
import type { MockSession, User } from "@/types/auth";

interface AuthContextValue extends MockSession {
  signIn: (user: User) => void;
  signOut: () => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const rawUser = window.localStorage.getItem("razi-mock-user");
    if (!rawUser) return;

    try {
      setUser(JSON.parse(rawUser) as User);
    } catch {
      window.localStorage.removeItem("razi-mock-user");
    }
  }, []);

  const signIn = useCallback((nextUser: User) => {
    persistMockSession(nextUser);
    setUser(nextUser);
  }, []);

  const signOut = useCallback(() => {
    destroyMockSession();
    setUser(null);
  }, []);

  const value = useMemo(
    () => ({
      isAuthenticated: Boolean(user),
      user,
      signIn,
      signOut
    }),
    [signIn, signOut, user]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);

  if (!context) {
    throw new Error("useAuth must be used within AuthProvider.");
  }

  return context;
}

export { createMockUser };
