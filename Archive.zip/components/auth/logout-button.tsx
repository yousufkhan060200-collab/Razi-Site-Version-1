"use client";

import { useRouter } from "next/navigation";

import { useAuth } from "@/components/auth/auth-provider";
import { Button } from "@/components/ui/button";

export function LogoutButton() {
  const router = useRouter();
  const { signOut } = useAuth();

  return (
    <Button
      onClick={() => {
        signOut();
        router.push("/login");
        router.refresh();
      }}
      size="sm"
      variant="secondary"
    >
      Log out
    </Button>
  );
}
