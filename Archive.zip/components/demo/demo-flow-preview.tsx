"use client";

import { useMemo, useState } from "react";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { demoComplaints } from "@/data/demo";

export function DemoFlowPreview() {
  const [activeComplaintId, setActiveComplaintId] = useState(demoComplaints[0].id);
  const [questionIndex, setQuestionIndex] = useState(0);

  const activeComplaint = useMemo(
    () =>
      demoComplaints.find((complaint) => complaint.id === activeComplaintId) ??
      demoComplaints[0],
    [activeComplaintId]
  );

  const activeQuestion = activeComplaint.questions[questionIndex];

  return (
    <div className="grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
      <Card className="bg-gradient-to-br from-white to-brand-50">
        <CardHeader className="space-y-2">
          <p className="text-sm font-semibold uppercase tracking-[0.18em] text-brand-600">
            Product demo
          </p>
          <h3 className="text-2xl font-semibold text-ink-900">
            Guided intake preview
          </h3>
          <p className="text-sm text-ink-600">{activeComplaint.intro}</p>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex flex-wrap gap-2">
            {demoComplaints.map((complaint) => (
              <button
                key={complaint.id}
                className={`rounded-full px-4 py-2 text-sm font-medium transition ${
                  complaint.id === activeComplaint.id
                    ? "bg-brand-500 text-white"
                    : "bg-white text-ink-700 ring-1 ring-brand-100 hover:bg-brand-50"
                }`}
                onClick={() => {
                  setActiveComplaintId(complaint.id);
                  setQuestionIndex(0);
                }}
                type="button"
              >
                {complaint.label}
              </button>
            ))}
          </div>

          <div className="rounded-3xl border border-brand-100 bg-white p-5">
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-ink-500">
              Sample intake prompt
            </p>
            <p className="mt-3 text-lg font-medium text-ink-900">
              {activeQuestion.label}
            </p>
            <p className="mt-4 text-sm leading-7 text-ink-600">
              {activeQuestion.answer}
            </p>
          </div>

          <div className="flex items-center gap-3">
            <Button
              disabled={questionIndex === 0}
              onClick={() => setQuestionIndex((current) => Math.max(0, current - 1))}
              variant="secondary"
            >
              Previous
            </Button>
            <Button
              onClick={() =>
                setQuestionIndex((current) =>
                  Math.min(activeComplaint.questions.length - 1, current + 1)
                )
              }
              variant="primary"
            >
              Next question
            </Button>
            <span className="text-xs text-ink-500">
              {questionIndex + 1} / {activeComplaint.questions.length}
            </span>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="space-y-2">
          <p className="text-sm font-semibold uppercase tracking-[0.18em] text-brand-600">
            Provider-ready output
          </p>
          <h3 className="text-2xl font-semibold text-ink-900">
            Sample structured summary
          </h3>
          <p className="text-sm text-ink-600">
            Believable mock output based on the demo flow, designed to preview the product without exposing the full patient app.
          </p>
        </CardHeader>
        <CardContent className="grid gap-5 md:grid-cols-2">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-ink-500">
              Age / Sex
            </p>
            <p className="mt-2 text-sm text-ink-800">
              {activeComplaint.report.ageSex}
            </p>
          </div>
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-ink-500">
              Chief Complaint
            </p>
            <p className="mt-2 text-sm text-ink-800">
              {activeComplaint.report.chiefComplaint}
            </p>
          </div>
          <div className="md:col-span-2">
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-ink-500">
              HPI
            </p>
            <p className="mt-2 text-sm leading-7 text-ink-700">
              {activeComplaint.report.hpi}
            </p>
          </div>
          <ReportList
            items={activeComplaint.report.pertinentPositives}
            title="Pertinent positives"
          />
          <ReportList
            items={activeComplaint.report.pertinentNegatives}
            title="Pertinent negatives"
          />
          <ReportList items={activeComplaint.report.timeline} title="Timeline" />
          <ReportList
            items={activeComplaint.report.medicationsTried}
            title="Medications tried"
          />
          <ReportList items={activeComplaint.report.currentMeds} title="Current meds" />
          <ReportList items={activeComplaint.report.extraNotes} title="Other notes" />
        </CardContent>
      </Card>
    </div>
  );
}

function ReportList({
  title,
  items
}: {
  title: string;
  items: string[];
}) {
  return (
    <div>
      <p className="text-xs font-semibold uppercase tracking-[0.18em] text-ink-500">
        {title}
      </p>
      <ul className="mt-2 space-y-2 text-sm text-ink-700">
        {items.map((item) => (
          <li key={item} className="rounded-2xl bg-brand-50 px-3 py-2">
            {item}
          </li>
        ))}
      </ul>
    </div>
  );
}
