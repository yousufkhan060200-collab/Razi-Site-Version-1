"use client";

import { useState } from "react";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input, Textarea } from "@/components/ui/form-fields";

export function ContactForm() {
  const [submitted, setSubmitted] = useState(false);

  return (
    <Card>
      <CardContent>
        <form
          className="grid gap-4"
          onSubmit={(event) => {
            event.preventDefault();
            setSubmitted(true);
          }}
        >
          <div className="grid gap-4 md:grid-cols-2">
            <Input label="Name" name="name" placeholder="Taylor Morgan" required />
            <Input
              label="Clinic / company"
              name="clinic"
              placeholder="North Valley Urgent Care"
              required
            />
          </div>
          <Input
            label="Email"
            name="email"
            placeholder="you@clinic.com"
            required
            type="email"
          />
          <Textarea
            label="Message"
            name="message"
            placeholder="Tell us about your current intake workflow, locations, or pilot goals."
            required
          />
          <div className="flex flex-wrap items-center gap-3">
            <Button type="submit">Request Demo</Button>
            <span className="text-xs text-ink-500">
              Frontend-only form for now. Hook this to CRM or email automation later.
            </span>
          </div>
          {submitted ? (
            <p className="rounded-2xl bg-emerald-50 px-4 py-3 text-sm text-emerald-700">
              Demo request captured locally for this starter. Connect this form to your CRM, email, or database next.
            </p>
          ) : null}
        </form>
      </CardContent>
    </Card>
  );
}
