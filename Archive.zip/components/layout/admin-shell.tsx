import Link from "next/link";

import { LogoutButton } from "@/components/auth/logout-button";
import { RaziLogo } from "@/components/branding/razi-logo";
import { adminNav } from "@/data/navigation";

export function AdminShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-ink-50">
      <div className="mx-auto grid max-w-7xl gap-6 px-6 py-6 lg:grid-cols-[260px_1fr]">
        <aside className="rounded-[2rem] border border-white bg-white p-5 shadow-card">
          <RaziLogo />
          <div className="mt-6 rounded-3xl bg-ink-900 p-4 text-white">
            <p className="text-sm font-medium">Owner workspace</p>
            <p className="mt-1 text-sm text-white/70">
              Monitor trials, subscriptions, and demo activity across clinics.
            </p>
          </div>
          <nav className="mt-6 grid gap-1">
            {adminNav.map((item) => (
              <Link
                key={item.href}
                className="rounded-2xl px-4 py-3 text-sm font-medium text-ink-600 transition hover:bg-brand-50 hover:text-ink-900"
                href={item.href}
              >
                {item.label}
              </Link>
            ))}
          </nav>
          <div className="mt-6">
            <LogoutButton />
          </div>
        </aside>
        <main className="space-y-6">{children}</main>
      </div>
    </div>
  );
}
