import Link from "next/link";

import { LogoutButton } from "@/components/auth/logout-button";
import { RaziLogo } from "@/components/branding/razi-logo";
import { Badge } from "@/components/ui/badge";
import { dashboardNav } from "@/data/navigation";
import type { Clinic } from "@/types/clinic";

export function DashboardShell({
  clinic,
  children
}: {
  clinic: Clinic;
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen bg-ink-50">
      <div className="mx-auto grid max-w-7xl gap-6 px-6 py-6 lg:grid-cols-[260px_1fr]">
        <aside className="rounded-[2rem] border border-white bg-white p-5 shadow-card">
          <RaziLogo />
          <div className="mt-6 rounded-3xl bg-brand-50 p-4">
            <p className="text-sm font-medium text-ink-900">{clinic.name}</p>
            <p className="mt-1 text-sm text-ink-600">{clinic.address}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              <Badge tone={clinic.subscriptionStatus === "active" ? "success" : clinic.subscriptionStatus === "trial" ? "brand" : "warning"}>
                {clinic.subscription.subscriptionStatus}
              </Badge>
            </div>
          </div>
          <nav className="mt-6 grid gap-1">
            {dashboardNav.map((item) => (
              <Link
                key={item.href}
                className="rounded-2xl px-4 py-3 text-sm font-medium text-ink-600 transition hover:bg-brand-50 hover:text-ink-900"
                href={item.href}
              >
                {item.label}
              </Link>
            ))}
          </nav>
          <div className="mt-6">
            <LogoutButton />
          </div>
        </aside>
        <main className="space-y-6">{children}</main>
      </div>
    </div>
  );
}
