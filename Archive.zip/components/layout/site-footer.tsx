import Link from "next/link";

import { RaziLogo } from "@/components/branding/razi-logo";
import { marketingCopy } from "@/data/copy";
import { publicNav } from "@/data/navigation";

export function SiteFooter() {
  return (
    <footer className="border-t border-brand-100 bg-white">
      <div className="mx-auto grid max-w-7xl gap-10 px-6 py-14 md:grid-cols-[1.2fr_0.8fr]">
        <div className="space-y-4">
          <RaziLogo />
          <p className="max-w-xl text-sm leading-7 text-ink-600">
            {marketingCopy.footerTagline}
          </p>
          <Link
            className="inline-flex text-sm font-medium text-brand-600 transition hover:text-brand-700"
            href="/contact"
          >
            Talk to the Razi team
          </Link>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          {publicNav.map((item) => (
            <Link
              key={item.href}
              className="text-sm text-ink-600 transition hover:text-ink-900"
              href={item.href}
            >
              {item.label}
            </Link>
          ))}
          <Link
            className="text-sm text-ink-600 transition hover:text-ink-900"
            href="/signup"
          >
            Start free trial
          </Link>
        </div>
      </div>
    </footer>
  );
}
