import Link from "next/link";

import { RaziLogo } from "@/components/branding/razi-logo";
import { Button } from "@/components/ui/button";
import { publicNav } from "@/data/navigation";

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-30 border-b border-white/60 bg-white/75 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-6 px-6 py-4">
        <RaziLogo />
        <nav className="hidden items-center gap-6 md:flex">
          {publicNav.map((item) => (
            <Link
              key={item.href}
              className="text-sm font-medium text-ink-600 transition hover:text-ink-900"
              href={item.href}
            >
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-3">
          <Link href="/login">
            <Button size="sm" variant="ghost">
              Log in
            </Button>
          </Link>
          <Link href="/contact">
            <Button size="sm">Request Demo</Button>
          </Link>
        </div>
      </div>
    </header>
  );
}
