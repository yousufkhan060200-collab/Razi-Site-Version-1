import Image from "next/image";
import Link from "next/link";

import { cn } from "@/lib/utils/cn";

interface RaziLogoProps {
  className?: string;
  showWordmark?: boolean;
}

export function RaziLogo({
  className,
  showWordmark = true
}: RaziLogoProps) {
  return (
    <Link className={cn("inline-flex items-center gap-3", className)} href="/">
      <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white shadow-card ring-1 ring-brand-100">
        {/* Replace this placeholder asset with the final production logo later. */}
        <Image
          alt="Razi quill logo placeholder"
          height={32}
          priority
          src="/razi-quill-placeholder.svg"
          width={32}
        />
      </span>
      {showWordmark ? (
        <span>
          <span className="block text-lg font-semibold text-ink-900">Razi</span>
          <span className="block text-xs text-ink-500">
            AI-assisted intake workflow
          </span>
        </span>
      ) : null}
    </Link>
  );
}
