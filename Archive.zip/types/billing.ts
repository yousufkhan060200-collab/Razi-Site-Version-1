export interface BillingInfo {
  stripeCustomerId: string;
  stripeSubscriptionId: string;
  billingEmail: string;
  cardBrand: string;
  last4: string;
  expMonth: number;
  expYear: number;
  paymentMethodLabel: string;
}
