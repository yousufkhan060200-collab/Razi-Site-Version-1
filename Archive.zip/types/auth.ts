export type UserRole = "clinic_user" | "admin";

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  clinicId?: string;
}

export interface MockSession {
  isAuthenticated: boolean;
  user: User | null;
}
