export interface UsagePoint {
  label: string;
  value: number;
}

export interface ClinicStats {
  totalIntakes: number;
  totalReports: number;
  estimatedMinutesSaved: number;
  estimatedStressReductionScore: number;
  estimatedStaffFrictionReduced: number;
  averageMinutesSavedPerIntake: number;
  weeklyUsage: UsagePoint[];
  monthlyUsage: UsagePoint[];
}

export interface AdminStats {
  totalUrgentCares: number;
  activeTrials: number;
  activeSubscriptions: number;
  canceledAccounts: number;
  totalReportsGenerated: number;
  totalEstimatedTimeSaved: number;
  totalEstimatedWorkflowBurdenReduced: number;
  totalEstimatedStaffFrictionReduced: number;
}
