export interface DemoQuestion {
  id: string;
  label: string;
  answer: string;
}

export interface DemoReport {
  ageSex: string;
  chiefComplaint: string;
  hpi: string;
  pertinentPositives: string[];
  pertinentNegatives: string[];
  timeline: string[];
  medicationsTried: string[];
  currentMeds: string[];
  extraNotes: string[];
}

export interface DemoComplaint {
  id: string;
  label: string;
  complaintCategory: string;
  intro: string;
  questions: DemoQuestion[];
  report: DemoReport;
}
