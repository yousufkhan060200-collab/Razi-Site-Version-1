export type SubscriptionStatus = "trial" | "active" | "canceled" | "expired";

export interface TrialWindow {
  startDate: string;
  endDate: string;
  daysRemaining: number;
  paymentRequired: boolean;
  statusLabel: string;
  message: string;
}

export interface Subscription {
  planName: string;
  billingCycle: "monthly" | "annual";
  subscriptionStatus: SubscriptionStatus;
  renewalDate?: string;
  cancelAtPeriodEnd: boolean;
  trial: TrialWindow;
  stripeCustomerId: string;
  stripeSubscriptionId: string;
}
