import type { BillingInfo } from "@/types/billing";
import type { ClinicStats } from "@/types/stats";
import type { Subscription, SubscriptionStatus } from "@/types/subscription";

export interface IntakeLinkMeta {
  clinicSlug: string;
  uniqueUrl: string;
  qrCodeUrl: string;
  shortCode: string;
}

export interface ClinicActivity {
  id: string;
  label: string;
  timestamp: string;
  value?: string;
}

export interface Clinic {
  id: string;
  slug: string;
  name: string;
  address: string;
  phone: string;
  contactName: string;
  contactEmail: string;
  uniqueUrl: string;
  qrCodeUrl: string;
  trialStartDate: string;
  trialEndDate: string;
  subscriptionStatus: SubscriptionStatus;
  stripeCustomerId: string;
  stripeSubscriptionId: string;
  intakeLink: IntakeLinkMeta;
  subscription: Subscription;
  billing: BillingInfo;
  stats: ClinicStats;
  recentActivity: ClinicActivity[];
  specialties: string[];
}
