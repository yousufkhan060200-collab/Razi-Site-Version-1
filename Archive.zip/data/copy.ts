export const marketingCopy = {
  hero: {
    eyebrow: "AI-assisted urgent care intake",
    title: "Smarter intake for urgent cares that need cleaner patient stories, faster.",
    description:
      "Razi guides patients through structured symptom questions and turns the conversation into a concise provider-ready summary so staff spend less time repeating intake work.",
    primaryCta: "Request Demo",
    secondaryCta: "See Product Demo"
  },
  valueProps: [
    "Save time at intake",
    "Capture better symptom history",
    "Generate cleaner summaries",
    "Improve staff workflow"
  ],
  painPoints: [
    "Patients repeat the same story to multiple people before the provider visit.",
    "Symptom histories vary depending on who asks the questions and how much time is available.",
    "Important contextual details can get missed in busy urgent care workflows.",
    "Waiting-room frustration grows when intake feels slow, repetitive, or unclear."
  ],
  howItWorks: [
    {
      title: "Patient opens the clinic intake link",
      description:
        "Each clinic gets a branded intake URL and QR code for easy access from the front desk, text, or signage."
    },
    {
      title: "Razi asks symptom-based follow-up questions",
      description:
        "The intake flow adapts to the complaint so patients answer clearer, more relevant questions without staff manually leading every step."
    },
    {
      title: "Structured intake summary is generated",
      description:
        "Responses are organized into a concise summary with HPI-style context, pertinent positives and negatives, and helpful timeline details."
    },
    {
      title: "Provider reviews and verifies",
      description:
        "The clinical team uses the summary as intake support, verifies the details, and applies clinician judgment before treatment decisions."
    }
  ],
  benefits: [
    {
      title: "Saves provider time",
      description: "Reduce repetitive questioning and start visits with a more organized symptom picture."
    },
    {
      title: "Improves intake consistency",
      description: "Use the same structured framework across shifts, staff members, and clinic locations."
    },
    {
      title: "Better symptom clarification",
      description: "Prompt patients with guided follow-up questions that surface useful context earlier."
    },
    {
      title: "Easy for patients",
      description: "Keep the experience simple, approachable, and understandable from phone to front desk."
    },
    {
      title: "Helps staff workflow",
      description: "Give staff a cleaner handoff instead of fragmented intake notes or repeated retelling."
    },
    {
      title: "Professional summaries",
      description: "Deliver provider-ready output that looks more structured than a raw chat transcript."
    }
  ],
  audiences: [
    "Urgent care groups",
    "Independent clinics",
    "Pilot rollout sites",
    "Outpatient intake workflows"
  ],
  disclaimer:
    "Razi is an AI-assisted intake support tool. It does not diagnose, replace clinician judgment, or remove the need for healthcare professionals to verify patient information.",
  footerTagline:
    "Razi helps urgent care teams collect structured symptom history and generate cleaner intake summaries."
};
