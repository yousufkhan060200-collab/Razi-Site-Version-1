export const publicNav = [
  { label: "Home", href: "/" },
  { label: "How It Works", href: "/how-it-works" },
  { label: "Demo", href: "/demo" },
  { label: "Benefits", href: "/benefits" },
  { label: "Contact", href: "/contact" }
];

export const dashboardNav = [
  { label: "Overview", href: "/dashboard" },
  { label: "Clinic Settings", href: "/dashboard/settings" },
  { label: "Billing", href: "/dashboard/billing" },
  { label: "Link + QR", href: "/dashboard/link" },
  { label: "Usage Stats", href: "/dashboard/stats" }
];

export const adminNav = [
  { label: "Overview", href: "/admin" },
  { label: "Urgent Cares", href: "/admin/clinics" }
];
