import { deriveClinicStats, deriveTrialWindow } from "@/lib/metrics";
import { generateQrCodeUrl } from "@/lib/qr";
import type { Clinic } from "@/types/clinic";

const clinicBase = [
  {
    id: "clinic-desert-urgent",
    slug: "desert-urgent-care",
    name: "Desert Urgent Care",
    address: "2401 N Central Ave, Phoenix, AZ 85004",
    phone: "(602) 555-0184",
    contactName: "Nadia Reyes",
    contactEmail: "ops@desert-urgent.com",
    subscriptionStatus: "trial" as const,
    trialStartDate: "2026-03-30",
    trialEndDate: "2026-04-13",
    stripeCustomerId: "cus_razi_desert_001",
    stripeSubscriptionId: "sub_razi_trial_001",
    specialties: ["Urgent care", "Walk-in", "Occupational health"],
    usage: {
      totalIntakes: 148,
      totalReports: 132,
      weeklyUsage: [
        { label: "Mon", value: 19 },
        { label: "Tue", value: 24 },
        { label: "Wed", value: 21 },
        { label: "Thu", value: 17 },
        { label: "Fri", value: 26 },
        { label: "Sat", value: 14 },
        { label: "Sun", value: 11 }
      ],
      monthlyUsage: [
        { label: "Jan", value: 42 },
        { label: "Feb", value: 61 },
        { label: "Mar", value: 97 },
        { label: "Apr", value: 132 }
      ]
    },
    recentActivity: [
      { id: "ra-1", label: "New intake link generated", timestamp: "2026-04-05T14:20:00Z" },
      { id: "ra-2", label: "14 reports generated today", timestamp: "2026-04-05T19:00:00Z" },
      { id: "ra-3", label: "Trial reminder email queued", timestamp: "2026-04-06T08:15:00Z" }
    ]
  },
  {
    id: "clinic-sunrise",
    slug: "sunrise-family-clinic",
    name: "Sunrise Family Clinic",
    address: "1180 Mesa View Blvd, Mesa, AZ 85201",
    phone: "(480) 555-0142",
    contactName: "Ariana Patel",
    contactEmail: "hello@sunriseclinic.com",
    subscriptionStatus: "active" as const,
    trialStartDate: "2026-02-18",
    trialEndDate: "2026-03-04",
    stripeCustomerId: "cus_razi_sunrise_002",
    stripeSubscriptionId: "sub_razi_active_002",
    specialties: ["Family medicine", "Same-day visits"],
    usage: {
      totalIntakes: 332,
      totalReports: 318,
      weeklyUsage: [
        { label: "Mon", value: 31 },
        { label: "Tue", value: 29 },
        { label: "Wed", value: 34 },
        { label: "Thu", value: 28 },
        { label: "Fri", value: 36 },
        { label: "Sat", value: 17 },
        { label: "Sun", value: 13 }
      ],
      monthlyUsage: [
        { label: "Jan", value: 112 },
        { label: "Feb", value: 181 },
        { label: "Mar", value: 247 },
        { label: "Apr", value: 318 }
      ]
    },
    recentActivity: [
      { id: "ra-4", label: "Billing portal opened", timestamp: "2026-04-04T11:05:00Z" },
      { id: "ra-5", label: "36 summaries generated this week", timestamp: "2026-04-05T20:10:00Z" },
      { id: "ra-6", label: "Clinic link copied by staff", timestamp: "2026-04-06T09:50:00Z" }
    ]
  },
  {
    id: "clinic-west-valley",
    slug: "west-valley-pilot",
    name: "West Valley Pilot Care",
    address: "8890 W McDowell Rd, Glendale, AZ 85305",
    phone: "(623) 555-0166",
    contactName: "Marcus Nguyen",
    contactEmail: "pilot@westvalleycare.com",
    subscriptionStatus: "canceled" as const,
    trialStartDate: "2026-03-10",
    trialEndDate: "2026-03-24",
    stripeCustomerId: "cus_razi_west_003",
    stripeSubscriptionId: "sub_razi_cancel_003",
    specialties: ["Pilot site", "After-hours clinic"],
    usage: {
      totalIntakes: 76,
      totalReports: 61,
      weeklyUsage: [
        { label: "Mon", value: 8 },
        { label: "Tue", value: 11 },
        { label: "Wed", value: 9 },
        { label: "Thu", value: 10 },
        { label: "Fri", value: 7 },
        { label: "Sat", value: 5 },
        { label: "Sun", value: 3 }
      ],
      monthlyUsage: [
        { label: "Jan", value: 0 },
        { label: "Feb", value: 0 },
        { label: "Mar", value: 38 },
        { label: "Apr", value: 61 }
      ]
    },
    recentActivity: [
      { id: "ra-7", label: "Subscription marked canceled", timestamp: "2026-04-01T17:40:00Z" },
      { id: "ra-8", label: "7 summaries generated last week", timestamp: "2026-04-05T16:20:00Z" },
      { id: "ra-9", label: "Reactivation offer pending", timestamp: "2026-04-06T08:40:00Z" }
    ]
  }
];

export const clinics: Clinic[] = clinicBase.map((clinic, index) => {
  const uniqueUrl = `https://razi.health/intake/${clinic.slug}`;
  const qrCodeUrl = generateQrCodeUrl(uniqueUrl);
  const stats = deriveClinicStats(clinic.usage);
  const trial = deriveTrialWindow(
    clinic.trialStartDate,
    clinic.trialEndDate,
    clinic.subscriptionStatus
  );

  return {
    id: clinic.id,
    slug: clinic.slug,
    name: clinic.name,
    address: clinic.address,
    phone: clinic.phone,
    contactName: clinic.contactName,
    contactEmail: clinic.contactEmail,
    uniqueUrl,
    qrCodeUrl,
    trialStartDate: clinic.trialStartDate,
    trialEndDate: clinic.trialEndDate,
    subscriptionStatus: clinic.subscriptionStatus,
    stripeCustomerId: clinic.stripeCustomerId,
    stripeSubscriptionId: clinic.stripeSubscriptionId,
    specialties: clinic.specialties,
    recentActivity: clinic.recentActivity,
    stats,
    intakeLink: {
      clinicSlug: clinic.slug,
      uniqueUrl,
      qrCodeUrl,
      shortCode: `UC-${index + 101}`
    },
    subscription: {
      planName:
        clinic.subscriptionStatus === "active"
          ? "Razi Growth"
          : clinic.subscriptionStatus === "canceled"
            ? "Pilot Plan"
            : "Free Trial",
      billingCycle: "monthly",
      subscriptionStatus: clinic.subscriptionStatus,
      renewalDate: clinic.subscriptionStatus === "active" ? "2026-05-01" : undefined,
      cancelAtPeriodEnd: clinic.subscriptionStatus === "canceled",
      trial,
      stripeCustomerId: clinic.stripeCustomerId,
      stripeSubscriptionId: clinic.stripeSubscriptionId
    },
    billing: {
      stripeCustomerId: clinic.stripeCustomerId,
      stripeSubscriptionId: clinic.stripeSubscriptionId,
      billingEmail: clinic.contactEmail,
      cardBrand: clinic.subscriptionStatus === "trial" ? "Visa" : "Mastercard",
      last4: clinic.subscriptionStatus === "trial" ? "4242" : "1881",
      expMonth: 11,
      expYear: 2028,
      paymentMethodLabel: clinic.subscriptionStatus === "expired" ? "No active payment method" : "Primary card on file"
    }
  };
});

export const primaryClinic = clinics[0];

export function getClinicById(id?: string) {
  return clinics.find((clinic) => clinic.id === id) ?? primaryClinic;
}
