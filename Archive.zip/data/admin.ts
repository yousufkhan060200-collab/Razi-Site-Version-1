import { clinics } from "@/data/clinics";
import { deriveAdminStats } from "@/lib/metrics";

export const adminStats = deriveAdminStats(clinics);

export const recentSignups = [
  {
    id: "signup-1",
    clinicName: "Desert Urgent Care",
    contactName: "Nadia Reyes",
    createdAt: "2026-04-01"
  },
  {
    id: "signup-2",
    clinicName: "Sunrise Family Clinic",
    contactName: "Ariana Patel",
    createdAt: "2026-03-18"
  },
  {
    id: "signup-3",
    clinicName: "West Valley Pilot Care",
    contactName: "Marcus Nguyen",
    createdAt: "2026-03-10"
  }
];

export const topClinicsByUsage = [...clinics]
  .sort((a, b) => b.stats.totalReports - a.stats.totalReports)
  .slice(0, 3);
