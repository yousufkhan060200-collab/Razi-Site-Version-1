import type { DemoComplaint } from "@/types/demo";

export const demoComplaints: DemoComplaint[] = [
  {
    id: "chest-pain",
    label: "Chest pain",
    complaintCategory: "Cardiopulmonary",
    intro: "Sample flow showing how Razi structures urgent chest pain intake without positioning itself as a diagnosis engine.",
    questions: [
      {
        id: "onset",
        label: "When did the discomfort start?",
        answer: "Started this morning around 7:30 AM while getting ready for work."
      },
      {
        id: "quality",
        label: "How would you describe it?",
        answer: "Pressure-like discomfort in the center of the chest, worse when walking fast."
      },
      {
        id: "associated",
        label: "Any shortness of breath or radiation?",
        answer: "Mild shortness of breath with activity. No jaw pain. Mild left shoulder pressure."
      }
    ],
    report: {
      ageSex: "52 / Male",
      chiefComplaint: "Chest pain",
      hpi: "Pressure-like central chest discomfort beginning this morning with mild exertional shortness of breath and slight left shoulder pressure. Symptoms prompted same-day urgent care presentation due to worsening intensity with activity.",
      pertinentPositives: ["Central chest pressure", "Mild SOB on exertion", "Left shoulder pressure"],
      pertinentNegatives: ["No syncope", "No jaw pain", "No known recent trauma"],
      timeline: ["7:30 AM symptom onset", "Worsened walking from parking lot", "No prior evaluation today"],
      medicationsTried: ["None reported"],
      currentMeds: ["Lisinopril", "Atorvastatin"],
      extraNotes: ["Patient reports concern because symptoms feel different from typical reflux."]
    }
  },
  {
    id: "abdominal-pain",
    label: "Abdominal pain",
    complaintCategory: "GI",
    intro: "Sample abdominal pain workflow focused on clean chronology, symptom clarification, and provider-ready documentation.",
    questions: [
      {
        id: "location",
        label: "Where is the pain located?",
        answer: "Mostly right lower abdomen with some generalized cramping."
      },
      {
        id: "duration",
        label: "How long has this been going on?",
        answer: "Started yesterday evening and became more constant overnight."
      },
      {
        id: "associated",
        label: "Associated symptoms?",
        answer: "Nausea present. No vomiting. Appetite reduced."
      }
    ],
    report: {
      ageSex: "29 / Female",
      chiefComplaint: "Abdominal pain",
      hpi: "Right lower abdominal pain beginning yesterday evening, progressing from intermittent cramping to more constant discomfort overnight. Associated nausea and reduced appetite without vomiting.",
      pertinentPositives: ["RLQ pain", "Nausea", "Reduced appetite"],
      pertinentNegatives: ["No vomiting", "No black stool", "No recent abdominal procedure"],
      timeline: ["Yesterday evening onset", "Overnight worsening", "Presented this afternoon due to persistence"],
      medicationsTried: ["Ibuprofen"],
      currentMeds: ["Multivitamin"],
      extraNotes: ["Patient wants evaluation because discomfort is more focused today than yesterday."]
    }
  },
  {
    id: "cough-fever",
    label: "Cough / fever",
    complaintCategory: "Respiratory",
    intro: "Sample respiratory complaint showing how Razi narrows symptom history into a cleaner intake summary for the clinical team.",
    questions: [
      {
        id: "duration",
        label: "How long have you been sick?",
        answer: "Three days with worsening cough and fever since last night."
      },
      {
        id: "cough",
        label: "Tell me about the cough.",
        answer: "Productive cough with yellow mucus and chest tightness when coughing."
      },
      {
        id: "fever",
        label: "Any measured temperature or breathing change?",
        answer: "Measured 101.8°F at home. Mild shortness of breath going upstairs."
      }
    ],
    report: {
      ageSex: "41 / Female",
      chiefComplaint: "Cough / fever",
      hpi: "Three-day respiratory illness with worsening productive cough, yellow sputum, fever to 101.8°F, and mild exertional shortness of breath. Presented due to progression overnight and concern about possible infection.",
      pertinentPositives: ["Productive cough", "Fever", "Chest tightness with cough", "Mild DOE"],
      pertinentNegatives: ["No hemoptysis", "No recent travel", "No known asthma exacerbation history today"],
      timeline: ["Day 1 scratchy throat", "Day 2 worsening cough", "Last night fever began"],
      medicationsTried: ["Acetaminophen", "Cough suppressant"],
      currentMeds: ["Albuterol inhaler PRN"],
      extraNotes: ["Patient says multiple family members have also been sick recently."]
    }
  },
  {
    id: "urinary",
    label: "Urinary symptoms",
    complaintCategory: "GU",
    intro: "Sample urinary complaint demonstrating structured follow-up questions and a concise summary output.",
    questions: [
      {
        id: "symptoms",
        label: "What symptoms are you having?",
        answer: "Burning with urination, frequency, and urgency since yesterday."
      },
      {
        id: "fever",
        label: "Any fever, chills, or flank pain?",
        answer: "No fever or chills. Mild lower abdominal pressure. No flank pain."
      },
      {
        id: "history",
        label: "Similar episodes before?",
        answer: "Had a UTI about a year ago that improved with antibiotics."
      }
    ],
    report: {
      ageSex: "35 / Female",
      chiefComplaint: "Urinary symptoms",
      hpi: "One day of dysuria, urinary frequency, and urgency with mild suprapubic pressure. No fever, chills, or flank pain. History of prior UTI approximately one year ago.",
      pertinentPositives: ["Dysuria", "Frequency", "Urgency", "Suprapubic pressure"],
      pertinentNegatives: ["No fever", "No flank pain", "No vomiting"],
      timeline: ["Yesterday morning onset", "Symptoms persisted through the day", "No other visit yet"],
      medicationsTried: ["Increased water intake", "Phenazopyridine"],
      currentMeds: ["None reported"],
      extraNotes: ["Patient requesting quick treatment before symptoms worsen."]
    }
  }
];
