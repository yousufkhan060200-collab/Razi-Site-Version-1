export const AUTH_COOKIE_KEYS = {
  role: "razi_mock_role",
  email: "razi_mock_email",
  name: "razi_mock_name",
  clinicId: "razi_mock_clinic"
} as const;

export const SAMPLE_ACCOUNTS = {
  clinicUser: {
    email: "ops@desert-urgent.com",
    password: "demo1234"
  },
  admin: {
    email: "admin@razihealth.com",
    password: "demo1234"
  }
} as const;
