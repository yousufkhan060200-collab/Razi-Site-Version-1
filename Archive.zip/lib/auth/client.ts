"use client";

import type { User, UserRole } from "@/types/auth";
import { AUTH_COOKIE_KEYS } from "@/lib/auth/constants";

function writeCookie(name: string, value: string) {
  document.cookie = `${name}=${encodeURIComponent(value)}; path=/; max-age=${60 * 60 * 12}; samesite=lax`;
}

function clearCookie(name: string) {
  document.cookie = `${name}=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT`;
}

export function persistMockSession(user: User) {
  clearCookie(AUTH_COOKIE_KEYS.clinicId);
  writeCookie(AUTH_COOKIE_KEYS.role, user.role);
  writeCookie(AUTH_COOKIE_KEYS.email, user.email);
  writeCookie(AUTH_COOKIE_KEYS.name, user.name);

  if (user.clinicId) {
    writeCookie(AUTH_COOKIE_KEYS.clinicId, user.clinicId);
  }

  window.localStorage.setItem("razi-mock-user", JSON.stringify(user));
}

export function destroyMockSession() {
  clearCookie(AUTH_COOKIE_KEYS.role);
  clearCookie(AUTH_COOKIE_KEYS.email);
  clearCookie(AUTH_COOKIE_KEYS.name);
  clearCookie(AUTH_COOKIE_KEYS.clinicId);
  window.localStorage.removeItem("razi-mock-user");
}

export function createMockUser(input: {
  name: string;
  email: string;
  role?: UserRole;
  clinicId?: string;
}) {
  const role = input.role ?? (input.email.includes("admin") ? "admin" : "clinic_user");

  return {
    id: role === "admin" ? "user-admin-1" : "user-clinic-1",
    name: input.name,
    email: input.email,
    role,
    clinicId: role === "clinic_user" ? input.clinicId ?? "clinic-desert-urgent" : undefined
  } satisfies User;
}
