import { cookies } from "next/headers";

import { AUTH_COOKIE_KEYS } from "@/lib/auth/constants";
import type { User } from "@/types/auth";

export async function getServerMockUser(): Promise<User | null> {
  const store = await cookies();
  const role = store.get(AUTH_COOKIE_KEYS.role)?.value;
  const email = store.get(AUTH_COOKIE_KEYS.email)?.value;
  const name = store.get(AUTH_COOKIE_KEYS.name)?.value;
  const clinicId = store.get(AUTH_COOKIE_KEYS.clinicId)?.value;

  if (!role || !email || !name) return null;

  return {
    id: role === "admin" ? "user-admin-1" : "user-clinic-1",
    role: role === "admin" ? "admin" : "clinic_user",
    email: decodeURIComponent(email),
    name: decodeURIComponent(name),
    clinicId: clinicId ? decodeURIComponent(clinicId) : undefined
  };
}
