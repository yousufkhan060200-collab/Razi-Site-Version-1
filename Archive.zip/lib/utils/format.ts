export function formatNumber(value: number) {
  return new Intl.NumberFormat("en-US").format(value);
}

export function formatDate(date: string) {
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric"
  }).format(new Date(date));
}

export function formatMinutesAsHours(minutes: number) {
  if (minutes < 60) return `${minutes} min`;

  const hours = (minutes / 60).toFixed(1);
  return `${hours} hrs`;
}
