export function generateQrCodeUrl(value: string) {
  const encoded = encodeURIComponent(value);

  // Placeholder implementation for v1 starter. Swap to a real QR generator or
  // server-side asset pipeline when the product is connected to persistence.
  return `https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${encoded}`;
}
