import type { AdminStats, ClinicStats, UsagePoint } from "@/types/stats";
import type { SubscriptionStatus } from "@/types/subscription";

export const METRIC_DEFAULTS = {
  minutesSavedPerReport: 6,
  workflowReliefWeight: 0.62,
  frictionReliefWeight: 0.41,
  trialLengthDays: 14
} as const;

export function deriveClinicStats(input: {
  totalIntakes: number;
  totalReports: number;
  weeklyUsage: UsagePoint[];
  monthlyUsage: UsagePoint[];
}): ClinicStats {
  const estimatedMinutesSaved =
    input.totalReports * METRIC_DEFAULTS.minutesSavedPerReport;
  const estimatedStressReductionScore = Math.round(
    input.totalReports * METRIC_DEFAULTS.workflowReliefWeight
  );
  const estimatedStaffFrictionReduced = Math.round(
    input.totalReports * METRIC_DEFAULTS.frictionReliefWeight
  );

  return {
    totalIntakes: input.totalIntakes,
    totalReports: input.totalReports,
    estimatedMinutesSaved,
    estimatedStressReductionScore,
    estimatedStaffFrictionReduced,
    averageMinutesSavedPerIntake: METRIC_DEFAULTS.minutesSavedPerReport,
    weeklyUsage: input.weeklyUsage,
    monthlyUsage: input.monthlyUsage
  };
}

export function deriveTrialWindow(
  trialStartDate: string,
  trialEndDate: string,
  subscriptionStatus: SubscriptionStatus
) {
  const now = new Date("2026-04-06T12:00:00.000Z");
  const end = new Date(trialEndDate);
  const start = new Date(trialStartDate);
  const daysRemaining = Math.max(
    0,
    Math.ceil((end.getTime() - now.getTime()) / (1000 * 60 * 60 * 24))
  );

  const paymentRequired = subscriptionStatus === "expired";
  const statusLabel =
    subscriptionStatus === "trial"
      ? `${daysRemaining} days left in trial`
      : subscriptionStatus === "active"
        ? "Subscription active"
        : subscriptionStatus === "canceled"
          ? "Canceled at period end"
          : "Payment required";

  const message =
    subscriptionStatus === "trial"
      ? `14-day free trial started ${start.toLocaleDateString("en-US")}. Cancel anytime before ${end.toLocaleDateString("en-US")}.`
      : subscriptionStatus === "expired"
        ? "Trial ended. Payment method required to continue new clinic intakes."
        : "Subscription status is mocked for this starter and ready for future Stripe wiring.";

  return {
    startDate: trialStartDate,
    endDate: trialEndDate,
    daysRemaining,
    paymentRequired,
    statusLabel,
    message
  };
}

export function deriveAdminStats(
  clinics: Array<{
    subscriptionStatus: SubscriptionStatus;
    stats: ClinicStats;
  }>
): AdminStats {
  return {
    totalUrgentCares: clinics.length,
    activeTrials: clinics.filter((clinic) => clinic.subscriptionStatus === "trial")
      .length,
    activeSubscriptions: clinics.filter(
      (clinic) => clinic.subscriptionStatus === "active"
    ).length,
    canceledAccounts: clinics.filter(
      (clinic) =>
        clinic.subscriptionStatus === "canceled" ||
        clinic.subscriptionStatus === "expired"
    ).length,
    totalReportsGenerated: clinics.reduce(
      (sum, clinic) => sum + clinic.stats.totalReports,
      0
    ),
    totalEstimatedTimeSaved: clinics.reduce(
      (sum, clinic) => sum + clinic.stats.estimatedMinutesSaved,
      0
    ),
    totalEstimatedWorkflowBurdenReduced: clinics.reduce(
      (sum, clinic) => sum + clinic.stats.estimatedStressReductionScore,
      0
    ),
    totalEstimatedStaffFrictionReduced: clinics.reduce(
      (sum, clinic) => sum + clinic.stats.estimatedStaffFrictionReduced,
      0
    )
  };
}
