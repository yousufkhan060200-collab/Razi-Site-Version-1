# Razi Site Starter

Structured marketing/demo starter for Razi built with the Next.js App Router, TypeScript, and Tailwind CSS.

## What is included

- Marketing pages for landing, how-it-works, demo, benefits, and contact
- Mock auth pages for login, signup, and forgot password
- Clinic dashboard framework with stats, billing, link/QR, and settings views
- Admin dashboard framework with overview, clinic list, and clinic detail pages
- Mock demo intake content modeled after the existing `Razi.html` product flow
- Shared types, mock data, design primitives, and middleware guard structure

## Project layout

- `app/`: route groups for marketing, auth, dashboard, admin, and intake preview
- `components/`: reusable UI, layout, branding, demo, auth, and dashboard building blocks
- `data/`: mock copy, demo complaints, clinic records, and admin summary inputs
- `lib/`: auth helpers, metrics engine, QR wrapper, and formatting utilities
- `types/`: shared domain interfaces

## Integration seams

- Real auth:
  Replace the mock cookie/localStorage helpers in `lib/auth/` and the client forms in `components/auth/`.
- Stripe:
  Wire `data/clinics.ts`, `types/subscription.ts`, and `components/dashboard/billing-panel.tsx` to live billing data and portal actions.
- Database:
  Move clinic, user, and stats records out of `data/` and into your persistence layer.
- QR generation:
  Replace the placeholder URL service in `lib/qr/index.ts` with generated assets or signed URLs.
- Analytics:
  Add CTA, demo interaction, and dashboard event tracking in the page-level components and form submit handlers.

## Local setup

This workspace did not have `node` or `npm` installed during implementation, so the code was scaffolded but not executed here.

Once Node is available:

```bash
npm install
npm run dev
```
