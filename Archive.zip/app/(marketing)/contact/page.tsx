import { ContactForm } from "@/components/marketing/contact-form";
import { Card, CardContent } from "@/components/ui/card";
import { SectionHeading } from "@/components/ui/section-heading";

export default function ContactPage() {
  return (
    <main className="page-shell section-gap">
      <div className="grid gap-10 lg:grid-cols-[0.8fr_1.2fr]">
        <div className="space-y-6">
          <SectionHeading
            eyebrow="Contact"
            title="Request a demo or pilot conversation"
            description="Give prospective urgent care customers a simple way to raise their hand while keeping implementation lightweight for now."
          />
          <Card>
            <CardContent className="space-y-4 text-sm leading-7 text-ink-600">
              <p>
                This starter keeps contact handling frontend-only so the project stays easy to extend later.
              </p>
              <p>
                Good future connection points: HubSpot, Resend, Postmark, a Supabase lead table, or a small API route that forwards demo requests.
              </p>
            </CardContent>
          </Card>
        </div>
        <ContactForm />
      </div>
    </main>
  );
}
