import { DemoFlowPreview } from "@/components/demo/demo-flow-preview";
import { Card, CardContent } from "@/components/ui/card";
import { SectionHeading } from "@/components/ui/section-heading";

export default function DemoPage() {
  return (
    <main className="page-shell section-gap space-y-12">
      <SectionHeading
        eyebrow="Interactive demo"
        title="Preview the intake experience from prompt to summary"
        description="This is a curated product preview built with local mock data. It demonstrates the shape of the workflow without exposing the real patient-facing app."
      />
      <DemoFlowPreview />
      <Card>
        <CardContent className="grid gap-4 md:grid-cols-3">
          <div>
            <h3 className="text-lg font-semibold text-ink-900">Complaint selection</h3>
            <p className="mt-2 text-sm leading-7 text-ink-600">
              Mirror realistic symptom categories like chest pain, abdominal pain, cough/fever, and urinary symptoms.
            </p>
          </div>
          <div>
            <h3 className="text-lg font-semibold text-ink-900">Guided questioning</h3>
            <p className="mt-2 text-sm leading-7 text-ink-600">
              Show believable AI follow-up prompts that feel clinically useful without over-claiming autonomy.
            </p>
          </div>
          <div>
            <h3 className="text-lg font-semibold text-ink-900">Summary output</h3>
            <p className="mt-2 text-sm leading-7 text-ink-600">
              Keep the output provider-friendly with HPI-style narrative, positives, negatives, and timeline structure.
            </p>
          </div>
        </CardContent>
      </Card>
    </main>
  );
}
