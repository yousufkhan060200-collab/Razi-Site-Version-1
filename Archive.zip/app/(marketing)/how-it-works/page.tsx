import { Card, CardContent } from "@/components/ui/card";
import { SectionHeading } from "@/components/ui/section-heading";
import { marketingCopy } from "@/data/copy";

export default function HowItWorksPage() {
  return (
    <main className="page-shell section-gap">
      <SectionHeading
        eyebrow="Workflow"
        title="How Razi fits into urgent care intake"
        description="Use this page to explain the operational flow in plain language for clinic owners, operators, and pilot partners."
      />
      <div className="mt-12 grid gap-5 lg:grid-cols-2">
        {marketingCopy.howItWorks.map((step, index) => (
          <Card key={step.title}>
            <CardContent>
              <p className="text-sm font-semibold text-brand-600">Step {index + 1}</p>
              <h2 className="mt-3 text-2xl font-semibold text-ink-900">
                {step.title}
              </h2>
              <p className="mt-4 text-base leading-8 text-ink-600">
                {step.description}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>
    </main>
  );
}
