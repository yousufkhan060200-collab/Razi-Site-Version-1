import { Card, CardContent } from "@/components/ui/card";
import { SectionHeading } from "@/components/ui/section-heading";
import { marketingCopy } from "@/data/copy";

export default function BenefitsPage() {
  return (
    <main className="page-shell section-gap">
      <SectionHeading
        eyebrow="Benefits"
        title="A clean SaaS benefits page for clinic buyers"
        description="This page keeps the pitch grounded in workflow improvement, summary quality, and intake consistency."
      />
      <div className="mt-12 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
        {marketingCopy.benefits.map((benefit) => (
          <Card key={benefit.title}>
            <CardContent>
              <h2 className="text-xl font-semibold text-ink-900">
                {benefit.title}
              </h2>
              <p className="mt-3 text-sm leading-7 text-ink-600">
                {benefit.description}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>
    </main>
  );
}
