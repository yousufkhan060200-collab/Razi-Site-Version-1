import Link from "next/link";

import { DemoFlowPreview } from "@/components/demo/demo-flow-preview";
import { ContactForm } from "@/components/marketing/contact-form";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { SectionHeading } from "@/components/ui/section-heading";
import { marketingCopy } from "@/data/copy";

export default function LandingPage() {
  return (
    <main>
      <section className="page-shell section-gap">
        <div className="grid items-center gap-14 lg:grid-cols-[1.05fr_0.95fr]">
          <div>
            <Badge className="mb-6" tone="brand">
              {marketingCopy.hero.eyebrow}
            </Badge>
            <h1 className="max-w-3xl text-5xl font-semibold tracking-tight text-ink-900 sm:text-6xl">
              {marketingCopy.hero.title}
            </h1>
            <p className="mt-6 max-w-2xl text-lg leading-8 text-ink-600">
              {marketingCopy.hero.description}
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="/contact">
                <Button size="lg">{marketingCopy.hero.primaryCta}</Button>
              </Link>
              <Link href="/demo">
                <Button size="lg" variant="secondary">
                  {marketingCopy.hero.secondaryCta}
                </Button>
              </Link>
            </div>
            <div className="mt-10 grid gap-3 sm:grid-cols-2">
              {marketingCopy.valueProps.map((item) => (
                <div
                  key={item}
                  className="rounded-3xl border border-brand-100 bg-white/80 px-4 py-4 text-sm font-medium text-ink-700 shadow-card"
                >
                  {item}
                </div>
              ))}
            </div>
          </div>

          <Card className="overflow-hidden bg-hero-glow">
            <CardContent className="space-y-6 p-8">
              {/* Future Claude polish point: hero visual can later evolve into a more animated product mockup. */}
              <div className="rounded-3xl border border-white bg-white p-5 shadow-soft">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-[0.18em] text-brand-600">
                      Sample clinic dashboard
                    </p>
                    <h2 className="mt-2 text-2xl font-semibold text-ink-900">
                      Intake workflow at a glance
                    </h2>
                  </div>
                  <Badge tone="success">Trial active</Badge>
                </div>
                <div className="mt-6 grid gap-4 sm:grid-cols-2">
                  <Metric label="Intakes completed" value="148" />
                  <Metric label="Reports generated" value="132" />
                  <Metric label="Estimated time saved" value="792 min" />
                  <Metric label="Average saved / intake" value="6 min" />
                </div>
              </div>
              <div className="rounded-3xl border border-brand-100 bg-white/90 p-5">
                <p className="text-xs font-semibold uppercase tracking-[0.18em] text-ink-500">
                  Product positioning
                </p>
                <p className="mt-3 text-sm leading-7 text-ink-700">
                  Razi helps clinics collect structured symptom history and generate a concise provider-ready summary. It supports intake workflows and clinician review. It does not replace clinician judgment.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      <section className="page-shell section-gap border-t border-brand-100">
        <SectionHeading
          eyebrow="Why Razi"
          title="Built for the messy middle of urgent care intake"
          description="The problem is rarely just data collection. It is repeated questioning, inconsistent prompting, fragmented notes, and rushed handoffs between patient, staff, and provider."
        />
        <div className="mt-10 grid gap-4 md:grid-cols-2">
          {marketingCopy.painPoints.map((point) => (
            <Card key={point}>
              <CardContent>
                <p className="text-base leading-7 text-ink-700">{point}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section className="page-shell section-gap border-t border-brand-100">
        <SectionHeading
          eyebrow="How it works"
          title="A structured flow from patient input to provider-ready summary"
          description="Use the marketing site to explain the workflow clearly before you build out the full product polish."
        />
        <div className="mt-10 grid gap-5 lg:grid-cols-4">
          {marketingCopy.howItWorks.map((step, index) => (
            <Card key={step.title}>
              <CardContent>
                <p className="text-sm font-semibold text-brand-600">Step {index + 1}</p>
                <h3 className="mt-3 text-xl font-semibold text-ink-900">
                  {step.title}
                </h3>
                <p className="mt-3 text-sm leading-7 text-ink-600">
                  {step.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section className="page-shell section-gap border-t border-brand-100" id="demo">
        <SectionHeading
          align="center"
          eyebrow="Demo preview"
          title="Show the workflow without shipping the full patient app"
          description="Visitors can switch between sample complaints, step through believable intake prompts, and inspect a structured summary output."
        />
        <div className="mt-12">
          <DemoFlowPreview />
        </div>
      </section>

      <section className="page-shell section-gap border-t border-brand-100">
        <SectionHeading
          eyebrow="Benefits"
          title="Position Razi like a healthcare SaaS product, not a diagnosis tool"
          description="The strongest message for urgent cares is operational clarity: better questions, better consistency, better summaries, and less repeated intake work."
        />
        <div className="mt-10 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {marketingCopy.benefits.map((benefit) => (
            <Card key={benefit.title}>
              <CardContent>
                <h3 className="text-xl font-semibold text-ink-900">
                  {benefit.title}
                </h3>
                <p className="mt-3 text-sm leading-7 text-ink-600">
                  {benefit.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section className="page-shell section-gap border-t border-brand-100">
        <div className="grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
          <Card>
            <CardContent className="space-y-5">
              <SectionHeading
                eyebrow="Who it is for"
                title="A flexible fit for clinic teams piloting intake improvements"
                description="Use this starter to market Razi to urgent cares, small clinics, and pilot environments before you wire production integrations."
              />
              <div className="grid gap-3 sm:grid-cols-2">
                {marketingCopy.audiences.map((item) => (
                  <div
                    key={item}
                    className="rounded-2xl bg-brand-50 px-4 py-3 text-sm font-medium text-ink-700"
                  >
                    {item}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-ink-900 text-white">
            <CardContent className="space-y-4">
              <p className="text-sm font-semibold uppercase tracking-[0.18em] text-brand-200">
                Trust + disclaimer
              </p>
              <h3 className="text-2xl font-semibold">AI-assisted intake support</h3>
              <p className="text-sm leading-7 text-white/80">
                {marketingCopy.disclaimer}
              </p>
              <div className="rounded-3xl bg-white/10 p-4 text-sm text-white/75">
                Recommended placement for future trust assets: privacy notes, pilot outcomes, deployment FAQs, and clinic workflow screenshots.
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      <section className="page-shell section-gap border-t border-brand-100" id="contact">
        <div className="grid gap-10 lg:grid-cols-[0.85fr_1.15fr]">
          <SectionHeading
            eyebrow="Request a demo"
            title="Turn the starter into a real top-of-funnel site"
            description="This form is intentionally frontend-only right now. It gives Claude a clean handoff point for CRM wiring, analytics events, and lead routing."
          />
          <ContactForm />
        </div>
      </section>
    </main>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl bg-brand-50 p-4">
      <p className="text-xs font-semibold uppercase tracking-[0.18em] text-ink-500">
        {label}
      </p>
      <p className="mt-2 text-2xl font-semibold text-ink-900">{value}</p>
    </div>
  );
}
