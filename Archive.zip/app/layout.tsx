import type { Metadata } from "next";

import { AuthProvider } from "@/components/auth/auth-provider";
import "@/app/globals.css";

export const metadata: Metadata = {
  title: "Razi | AI-assisted intake for urgent care teams",
  description:
    "Razi is a demo and marketing site starter for an AI-assisted patient intake workflow product designed for urgent cares and clinics."
};

export default function RootLayout({
  children
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>
        <AuthProvider>{children}</AuthProvider>
      </body>
    </html>
  );
}
