import { UsageChart } from "@/components/dashboard/usage-chart";
import { Card, CardContent } from "@/components/ui/card";
import { getClinicById } from "@/data/clinics";
import { getServerMockUser } from "@/lib/auth/server";
import { formatNumber } from "@/lib/utils/format";

export default async function DashboardStatsPage() {
  const user = await getServerMockUser();
  const clinic = getClinicById(user?.clinicId);

  return (
    <div className="space-y-6">
      <Card>
        <CardContent className="grid gap-4 md:grid-cols-3">
          <Metric label="Reports generated" value={formatNumber(clinic.stats.totalReports)} />
          <Metric
            label="Estimated workflow burden reduced"
            value={formatNumber(clinic.stats.estimatedStressReductionScore)}
          />
          <Metric
            label="Estimated staff friction reduced"
            value={formatNumber(clinic.stats.estimatedStaffFrictionReduced)}
          />
        </CardContent>
      </Card>
      <div className="grid gap-6 xl:grid-cols-2">
        <UsageChart points={clinic.stats.weeklyUsage} title="Weekly usage trend" />
        <UsageChart points={clinic.stats.monthlyUsage} title="Monthly usage trend" />
      </div>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-3xl border border-brand-100 bg-white p-5 shadow-card">
      <p className="text-xs font-semibold uppercase tracking-[0.18em] text-ink-500">
        {label}
      </p>
      <p className="mt-2 text-3xl font-semibold text-ink-900">{value}</p>
    </div>
  );
}
