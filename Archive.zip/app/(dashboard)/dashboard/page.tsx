import { IntakeLinkCard } from "@/components/dashboard/intake-link-card";
import { UsageChart } from "@/components/dashboard/usage-chart";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { StatCard } from "@/components/ui/stat-card";
import { getClinicById } from "@/data/clinics";
import { getServerMockUser } from "@/lib/auth/server";
import { formatMinutesAsHours, formatNumber } from "@/lib/utils/format";

export default async function DashboardHomePage() {
  const user = await getServerMockUser();
  const clinic = getClinicById(user?.clinicId);

  return (
    <>
      <Card className="bg-white">
        <CardContent className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.18em] text-brand-600">
              Clinic dashboard
            </p>
            <h1 className="mt-2 text-4xl font-semibold tracking-tight text-ink-900">
              {clinic.name}
            </h1>
            <p className="mt-3 max-w-2xl text-sm leading-7 text-ink-600">
              Track demo activity, trial status, intake link distribution, and estimated workflow impact for your clinic.
            </p>
          </div>
          <div className="flex flex-wrap gap-3">
            <Badge tone={clinic.subscriptionStatus === "trial" ? "brand" : "success"}>
              {clinic.subscription.trial.statusLabel}
            </Badge>
            <Badge tone="neutral">{clinic.phone}</Badge>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        <StatCard
          detail="Estimated"
          label="Total intakes completed"
          value={formatNumber(clinic.stats.totalIntakes)}
        />
        <StatCard
          detail="Structured summary count"
          label="Reports generated"
          value={formatNumber(clinic.stats.totalReports)}
        />
        <StatCard
          detail="Estimated"
          label="Estimated Time Saved"
          value={formatMinutesAsHours(clinic.stats.estimatedMinutesSaved)}
        />
        <StatCard
          detail="Estimated index"
          label="Estimated Workflow Burden Reduced"
          value={formatNumber(clinic.stats.estimatedStressReductionScore)}
        />
        <StatCard
          detail="Estimated index"
          label="Estimated Staff Friction Reduced"
          value={formatNumber(clinic.stats.estimatedStaffFrictionReduced)}
        />
        <StatCard
          detail="Configurable starter constant"
          label="Average time saved per intake"
          value={`${clinic.stats.averageMinutesSavedPerIntake} min`}
        />
      </div>

      <div className="grid gap-6 xl:grid-cols-[1.15fr_0.85fr]">
        <UsageChart points={clinic.stats.weeklyUsage} title="Weekly intake usage" />
        <IntakeLinkCard clinic={clinic} />
      </div>

      <Card>
        <CardContent>
          <h2 className="text-xl font-semibold text-ink-900">Recent activity</h2>
          <div className="mt-5 grid gap-3">
            {clinic.recentActivity.map((activity) => (
              <div
                key={activity.id}
                className="flex flex-col justify-between gap-2 rounded-2xl border border-brand-100 bg-brand-50 p-4 md:flex-row md:items-center"
              >
                <p className="text-sm font-medium text-ink-800">{activity.label}</p>
                <p className="text-xs text-ink-500">{activity.timestamp}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </>
  );
}
