import { BillingPanel } from "@/components/dashboard/billing-panel";
import { getClinicById } from "@/data/clinics";
import { getServerMockUser } from "@/lib/auth/server";

export default async function DashboardBillingPage() {
  const user = await getServerMockUser();
  const clinic = getClinicById(user?.clinicId);

  return <BillingPanel clinic={clinic} />;
}
