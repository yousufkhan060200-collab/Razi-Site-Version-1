import { IntakeLinkCard } from "@/components/dashboard/intake-link-card";
import { Card, CardContent } from "@/components/ui/card";
import { getClinicById } from "@/data/clinics";
import { getServerMockUser } from "@/lib/auth/server";

export default async function DashboardLinkPage() {
  const user = await getServerMockUser();
  const clinic = getClinicById(user?.clinicId);

  return (
    <div className="space-y-6">
      <IntakeLinkCard clinic={clinic} />
      <Card>
        <CardContent className="space-y-3">
          <h2 className="text-xl font-semibold text-ink-900">
            Future integration notes
          </h2>
          <p className="text-sm leading-7 text-ink-600">
            Wire this page to your clinic provisioning logic, branded domains, QR asset storage, and analytics tracking when the backend is ready.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
