import { Card, CardContent } from "@/components/ui/card";
import { Input, Textarea } from "@/components/ui/form-fields";
import { getClinicById } from "@/data/clinics";
import { getServerMockUser } from "@/lib/auth/server";

export default async function DashboardSettingsPage() {
  const user = await getServerMockUser();
  const clinic = getClinicById(user?.clinicId);

  return (
    <Card>
      <CardContent className="space-y-6">
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.18em] text-brand-600">
            Clinic settings
          </p>
          <h1 className="mt-2 text-3xl font-semibold text-ink-900">
            Clinic profile
          </h1>
          <p className="mt-3 text-sm leading-7 text-ink-600">
            This starter uses form structure only. Connect these fields to your database and real auth tenant model later.
          </p>
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          <Input defaultValue={clinic.name} label="Clinic name" />
          <Input defaultValue={clinic.contactName} label="Primary contact" />
          <Input defaultValue={clinic.contactEmail} label="Contact email" />
          <Input defaultValue={clinic.phone} label="Clinic phone" />
        </div>
        <Textarea defaultValue={clinic.address} label="Clinic address" />
      </CardContent>
    </Card>
  );
}
