import { DashboardShell } from "@/components/layout/dashboard-shell";
import { getClinicById } from "@/data/clinics";
import { getServerMockUser } from "@/lib/auth/server";

export default async function DashboardLayout({
  children
}: {
  children: React.ReactNode;
}) {
  const user = await getServerMockUser();
  const clinic = getClinicById(user?.clinicId);

  return <DashboardShell clinic={clinic}>{children}</DashboardShell>;
}
