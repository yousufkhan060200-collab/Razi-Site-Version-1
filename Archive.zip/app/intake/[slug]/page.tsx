import { notFound } from "next/navigation";

import { RaziLogo } from "@/components/branding/razi-logo";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { clinics } from "@/data/clinics";

export default function IntakePreviewPage({
  params
}: {
  params: { slug: string };
}) {
  const clinic = clinics.find((entry) => entry.slug === params.slug);

  if (!clinic) {
    notFound();
  }

  return (
    <main className="flex min-h-screen items-center justify-center px-6 py-12">
      <Card className="w-full max-w-3xl">
        <CardContent className="space-y-8 p-8">
          <RaziLogo />
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.18em] text-brand-600">
              Clinic intake preview
            </p>
            <h1 className="mt-2 text-4xl font-semibold tracking-tight text-ink-900">
              {clinic.name}
            </h1>
            <p className="mt-4 text-sm leading-7 text-ink-600">
              This page previews what a clinic-specific intake entry point could look like once the real patient-facing workflow is connected. For now, it functions as a branded mock destination for links and QR codes shown in the marketing and dashboard experience.
            </p>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            <InfoBox
              label="Clinic address"
              value={clinic.address}
            />
            <InfoBox
              label="Clinic phone"
              value={clinic.phone}
            />
          </div>
          <div className="rounded-3xl bg-brand-50 p-5 text-sm leading-7 text-ink-700">
            Razi will eventually hand patients into the real intake workflow here. This preview keeps the SaaS shell complete while staying separate from the actual app.
          </div>
          <Button className="w-full sm:w-auto">Start intake preview</Button>
        </CardContent>
      </Card>
    </main>
  );
}

function InfoBox({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-3xl border border-brand-100 bg-white p-4">
      <p className="text-xs font-semibold uppercase tracking-[0.18em] text-ink-500">
        {label}
      </p>
      <p className="mt-2 text-sm text-ink-800">{value}</p>
    </div>
  );
}
