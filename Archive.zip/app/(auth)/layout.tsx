import { RaziLogo } from "@/components/branding/razi-logo";

export default function AuthLayout({
  children
}: {
  children: React.ReactNode;
}) {
  return (
    <main className="flex min-h-screen items-center justify-center px-6 py-12">
      <div className="w-full max-w-3xl space-y-6">
        <div className="flex justify-center">
          <RaziLogo />
        </div>
        {children}
      </div>
    </main>
  );
}
