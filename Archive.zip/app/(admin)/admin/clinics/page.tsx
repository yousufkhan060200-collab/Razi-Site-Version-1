import Link from "next/link";

import { Badge } from "@/components/ui/badge";
import { DataTable } from "@/components/ui/data-table";
import { clinics } from "@/data/clinics";
import { formatMinutesAsHours, formatNumber } from "@/lib/utils/format";

export default function AdminClinicsPage() {
  return (
    <div className="space-y-6">
      <div>
        <p className="text-sm font-semibold uppercase tracking-[0.18em] text-brand-600">
          Urgent care list
        </p>
        <h1 className="mt-2 text-4xl font-semibold tracking-tight text-ink-900">
          Clinics and subscriptions
        </h1>
      </div>

      <DataTable
        columns={[
          {
            header: "Urgent care",
            key: "name",
            render: (clinic) => (
              <div>
                <p className="font-medium text-ink-900">{clinic.name}</p>
                <p className="mt-1 text-xs text-ink-500">{clinic.address}</p>
              </div>
            )
          },
          { header: "Phone", key: "phone" },
          {
            header: "Contact",
            key: "contactName",
            render: (clinic) => (
              <div>
                <p>{clinic.contactName}</p>
                <p className="mt-1 text-xs text-ink-500">{clinic.contactEmail}</p>
              </div>
            )
          },
          {
            header: "Status",
            key: "subscriptionStatus",
            render: (clinic) => (
              <Badge
                tone={
                  clinic.subscriptionStatus === "active"
                    ? "success"
                    : clinic.subscriptionStatus === "trial"
                      ? "brand"
                      : "warning"
                }
              >
                {clinic.subscriptionStatus}
              </Badge>
            )
          },
          { header: "Stripe customer", key: "stripeCustomerId" },
          {
            header: "Usage",
            key: "stats",
            render: (clinic) => (
              <div>
                <p>{formatNumber(clinic.stats.totalReports)} reports</p>
                <p className="mt-1 text-xs text-ink-500">
                  {formatMinutesAsHours(clinic.stats.estimatedMinutesSaved)} saved
                </p>
              </div>
            )
          },
          {
            header: "Detail",
            key: "id",
            render: (clinic) => (
              <Link className="font-medium text-brand-600" href={`/admin/clinics/${clinic.id}`}>
                Open
              </Link>
            )
          }
        ]}
        getRowKey={(clinic) => clinic.id}
        rows={clinics}
      />
    </div>
  );
}
