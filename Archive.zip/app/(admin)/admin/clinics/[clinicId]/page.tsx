import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { StatCard } from "@/components/ui/stat-card";
import { clinics } from "@/data/clinics";
import { formatMinutesAsHours, formatNumber } from "@/lib/utils/format";

export default function AdminClinicDetailPage({
  params
}: {
  params: { clinicId: string };
}) {
  const clinic = clinics.find((entry) => entry.id === params.clinicId) ?? clinics[0];

  return (
    <div className="space-y-6">
      <Card>
        <CardContent className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.18em] text-brand-600">
              Clinic detail
            </p>
            <h1 className="mt-2 text-4xl font-semibold tracking-tight text-ink-900">
              {clinic.name}
            </h1>
            <p className="mt-3 text-sm leading-7 text-ink-600">
              {clinic.address} • {clinic.phone}
            </p>
          </div>
          <div className="flex flex-wrap gap-3">
            <Badge tone={clinic.subscriptionStatus === "active" ? "success" : clinic.subscriptionStatus === "trial" ? "brand" : "warning"}>
              {clinic.subscriptionStatus}
            </Badge>
            <Badge tone="neutral">{clinic.contactName}</Badge>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Total reports" value={formatNumber(clinic.stats.totalReports)} />
        <StatCard
          label="Estimated Time Saved"
          value={formatMinutesAsHours(clinic.stats.estimatedMinutesSaved)}
        />
        <StatCard
          label="Estimated Workflow Burden Reduced"
          value={formatNumber(clinic.stats.estimatedStressReductionScore)}
        />
        <StatCard
          label="Estimated Staff Friction Reduced"
          value={formatNumber(clinic.stats.estimatedStaffFrictionReduced)}
        />
      </div>

      <div className="grid gap-6 xl:grid-cols-2">
        <Card>
          <CardContent className="space-y-4">
            <h2 className="text-xl font-semibold text-ink-900">Subscription metadata</h2>
            <InfoLine label="Stripe customer ID" value={clinic.stripeCustomerId} />
            <InfoLine
              label="Stripe subscription ID"
              value={clinic.stripeSubscriptionId}
            />
            <InfoLine
              label="Trial window"
              value={`${clinic.trialStartDate} to ${clinic.trialEndDate}`}
            />
            <InfoLine label="Unique link" value={clinic.uniqueUrl} />
          </CardContent>
        </Card>
        <Card>
          <CardContent className="space-y-4">
            <h2 className="text-xl font-semibold text-ink-900">Recent activity</h2>
            {clinic.recentActivity.map((activity) => (
              <div
                key={activity.id}
                className="rounded-2xl bg-brand-50 px-4 py-3 text-sm text-ink-700"
              >
                <p className="font-medium text-ink-900">{activity.label}</p>
                <p className="mt-1 text-xs text-ink-500">{activity.timestamp}</p>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function InfoLine({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-brand-100 bg-white px-4 py-3">
      <p className="text-xs font-semibold uppercase tracking-[0.18em] text-ink-500">
        {label}
      </p>
      <p className="mt-2 break-all text-sm text-ink-800">{value}</p>
    </div>
  );
}
