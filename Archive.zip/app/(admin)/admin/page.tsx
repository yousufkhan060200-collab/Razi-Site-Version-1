import Link from "next/link";

import { Card, CardContent } from "@/components/ui/card";
import { StatCard } from "@/components/ui/stat-card";
import { adminStats, recentSignups, topClinicsByUsage } from "@/data/admin";
import { formatMinutesAsHours, formatNumber } from "@/lib/utils/format";

export default function AdminOverviewPage() {
  return (
    <>
      <Card>
        <CardContent>
          <p className="text-sm font-semibold uppercase tracking-[0.18em] text-brand-600">
            Admin overview
          </p>
          <h1 className="mt-2 text-4xl font-semibold tracking-tight text-ink-900">
            Razi owner dashboard
          </h1>
          <p className="mt-3 max-w-2xl text-sm leading-7 text-ink-600">
            Monitor signups, trial conversion, total summary output, and estimated workflow relief across the platform.
          </p>
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Total urgent cares" value={formatNumber(adminStats.totalUrgentCares)} />
        <StatCard label="Active trials" value={formatNumber(adminStats.activeTrials)} />
        <StatCard
          label="Active subscriptions"
          value={formatNumber(adminStats.activeSubscriptions)}
        />
        <StatCard label="Canceled accounts" value={formatNumber(adminStats.canceledAccounts)} />
        <StatCard
          label="Total reports generated"
          value={formatNumber(adminStats.totalReportsGenerated)}
        />
        <StatCard
          label="Estimated Time Saved"
          value={formatMinutesAsHours(adminStats.totalEstimatedTimeSaved)}
        />
        <StatCard
          label="Estimated Workflow Burden Reduced"
          value={formatNumber(adminStats.totalEstimatedWorkflowBurdenReduced)}
        />
        <StatCard
          label="Estimated Staff Friction Reduced"
          value={formatNumber(adminStats.totalEstimatedStaffFrictionReduced)}
        />
      </div>

      <div className="grid gap-6 xl:grid-cols-2">
        <Card>
          <CardContent>
            <h2 className="text-xl font-semibold text-ink-900">Recent signups</h2>
            <div className="mt-5 grid gap-3">
              {recentSignups.map((signup) => (
                <div
                  key={signup.id}
                  className="rounded-2xl border border-brand-100 bg-brand-50 p-4"
                >
                  <p className="font-medium text-ink-900">{signup.clinicName}</p>
                  <p className="mt-1 text-sm text-ink-600">
                    {signup.contactName} • {signup.createdAt}
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent>
            <h2 className="text-xl font-semibold text-ink-900">Top clinics by usage</h2>
            <div className="mt-5 grid gap-3">
              {topClinicsByUsage.map((clinic) => (
                <Link
                  key={clinic.id}
                  className="rounded-2xl border border-brand-100 bg-white p-4 transition hover:border-brand-300 hover:bg-brand-50"
                  href={`/admin/clinics/${clinic.id}`}
                >
                  <p className="font-medium text-ink-900">{clinic.name}</p>
                  <p className="mt-1 text-sm text-ink-600">
                    {clinic.stats.totalReports} reports • {clinic.subscription.subscriptionStatus}
                  </p>
                </Link>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
